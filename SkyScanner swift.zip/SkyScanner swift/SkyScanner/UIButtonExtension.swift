//
//  UIButtonExtension.swift
//  SkyScanner
//
//  Created by 翁志方 on 16/9/14.
//  Copyright © 2016年 翁志方. All rights reserved.
//

import UIKit

extension UIButton
{
    func setSelector(){
        
    }
}
